﻿using Newtonsoft.Json.Linq;
using System;
using System.ServiceProcess;
using System.Text;
using System.IO;
using System.Net;

namespace Gold_without_log_
{
    class CheckStatus
    {
        public void Check()
        {
            string a = null;
            CompareRobots cmp = new CompareRobots();
            RetrieveRobots rt = new RetrieveRobots();
            StringBuilder strbuffer = new StringBuilder();



            string[] linesOfMyRobots = System.IO.File.ReadAllLines(@"Daily_Sheduled_Robots.txt");
            //  string robotName = null;
            //  int a = 0;
            //StringBuilder line = new StringBuilder();

            string[] AvailableRobots = cmp.Compare();


                String timeStamp = GetTimestamp(DateTime.Now);
                String filename = "Result_On_" + timeStamp + ".txt";

                foreach (string line in AvailableRobots)
                {
                    //    String line = lines[pos];

                    var Today = DateTime.Now;
                    var Yesterday = DateTime.Now.AddDays(-1);
                    string x = Today.ToString("yyyy-MM-dd");
                    string y = Yesterday.ToString("yyyy-MM-dd");
                try
                {
                    string v = string.Format("http://checkmate.ukwest.cloudapp.azure.com:9100/documentServer/documentRepository/documents?query=SourceUrl:" + "\"" + "{0}" + "\"" + " AND PublishDate:" + "[" + y + " TO " + x + "]&sortByField=PublishDate&sortDescending=true", line.Trim());  //Adding Date


                    var response2 = new WebClient().DownloadString(v);

               

                
                    JObject jObj1 = JObject.Parse(response2);// C# object of JSONJObject jObj1 = JObject.Parse(response2);// C# object of JSON

                    if (jObj1["Documents"] != null && jObj1["Documents"].HasValues == true )
                    {
                        string id = (string)jObj1["Documents"][0]["_id"];

                        if (response2 != null && string.IsNullOrEmpty(id) == false)
                        {

                            //log.Info("ROBOID\tSUCCESS");
                            //  strbuffer.Append(line + "====== Is Working\n");
                          

                            strbuffer.Append("The url of Robot= " + line+ "is  working\n");
                      
                           
                        }
                   
                    }
                    else
                    {
                        strbuffer.Append("The url of Robot= " + line + " is not working \n");
                    }


                }
                catch (Exception e)
                {
                    a = line;
                }

                //if (cmp.Compare().Equals(true))
                //{
                //    strbuffer.Append("The url of Robot= " + line + " is not Available in server\n");
                //}


                //if (rt.GetRobots().Equals(true))
                //{
                //    strbuffer.Append("ROBOTS ARE NOT AVAILABLE or SERVER ERROR\n");
                //}
            }
            if (string.IsNullOrEmpty(a))
            {
                foreach (string line3 in linesOfMyRobots)
                {
                    if (line3 != a)
                    {
                        strbuffer.Append("The url of Robot= " + line3 + " is not Available in server \n");
                    }
                }
            }


            File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + filename, strbuffer.ToString());
            }
            

            public String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmss");
        }

    }
    }

