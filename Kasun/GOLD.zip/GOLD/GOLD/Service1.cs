﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;
using System.Web;
using log4net;


[assembly: log4net.Config.XmlConfigurator(Watch =true)]
namespace GOLD
{
    public partial class Service1 : ServiceBase
    {
        ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public Service1()
        {
            InitializeComponent();
        }

        public void OnDebug()
        {

            OnStart(null);
        }

        protected override void OnStart(string[] args)
        {






            /////////////////////////////////////////////////////////


            //var response = new WebClient().DownloadString("http://checkmate.ukwest.cloudapp.azure.com:9100/documentServer/mongo/EntityCard?query=_schema:WebSource&itemsPerPage=50");


            //JObject jObj = JObject.Parse(response);

            //for (int i = 0; i < 10; i++) {                                                          
            //    string url = (string)jObj["Documents"][i]["sourceUrl"];

            //    if (string.IsNullOrEmpty(url) == false)
            //    {
            //        String ms = String.Format("{0} {1}", url, Environment.NewLine);
                   

            //        File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + "OnStart36.txt", ms);
            //    }
            //}




            //////////////////////////////////////////////////////////



            string[] lines = System.IO.File.ReadAllLines(@"C:\Users\MPOC0125\Documents\visual studio 2015\Projects\GOLD\GOLD\bin\Debug\Daily_Sheduled_Robots.txt");

            String timeStamp = GetTimestamp(DateTime.Now);
            String filename = "Result_On_" + timeStamp + ".txt";     //Result TEXT file


            foreach (string line in lines)
            {
                var Today = DateTime.Now;
                var Yesterday = DateTime.Now.AddDays(-1);
                string x = Today.ToString("yyyy-MM-dd");
                string y = Yesterday.ToString("yyyy-MM-dd");

                string v = string.Format("http://checkmate.ukwest.cloudapp.azure.com:9100/documentServer/documentRepository/documents?query=SourceUrl:" + "\"" + "{0}" + "\"" + " AND PublishDate:" + "[" + y + " TO " + x + "]&sortByField=PublishDate&sortDescending=true", line);  //Adding Date

                try
                {

                    var response2 = new WebClient().DownloadString(v);
                    JObject jObj1 = JObject.Parse(response2);// C# object of JSONJObject jObj1 = JObject.Parse(response2);// C# object of JSON
                    StringBuilder strbuffer = new StringBuilder();
                    try
                    {
                        string url1 = (string)jObj1["Documents"][1]["_id"];





                        if (string.IsNullOrEmpty(url1)==false)
                        {
                            //log.Info("ROBOID\tSUCCESS");
                            strbuffer.Append(line + " Is Working\n");

                            try
                            {

                                log.Info(line + " Is Working\n");
                            }
                            catch (Exception ex)
                            {
                                log.Error(ex.Message);

                                throw;
                            }


                        }
                        else
                        {
                            strbuffer.Append(line + " Is Not Working\n");


                            try
                            {

                                log.Info(line + " Is Not Working\n");
                            }
                            catch (Exception ex)
                            {
                                log.Error(ex.Message);

                                throw;
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                    File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + filename, strbuffer.ToString());
                }
                
                catch (Exception e)
                {
                    Console.WriteLine(e);

                }


            
               
               
               

            }
        }
        protected override void OnStop()
        {
            try
            {

                log.Info( "Service Stopped");
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);

                throw;
            }
        }

        public String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmss");
        }
    }
}
