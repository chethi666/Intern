﻿using Newtonsoft.Json.Linq;
using System;
using System.ServiceProcess;
using System.Text;
using System.IO;
using System.Net;


namespace Gold_without_log_
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        public void OnDebug() {
            OnStart(null);

        }


        StringBuilder strbuffer = new StringBuilder();

        protected override void OnStart(string[] args)
        {




            var response = new WebClient().DownloadString("http://checkmate.ukwest.cloudapp.azure.com:9100/documentServer/mongo/EntityCard?query=_schema:WebSource&itemsPerPage=50");


            JObject jObj = JObject.Parse(response);

            
            int length = jObj.Count;

            for (int i = 0; i <length;i++)
            {
                string url = (string)jObj["Documents"][i]["sourceUrl"];

                if (string.IsNullOrEmpty(url) == false)
                {
                    String ms = String.Format("{0} {1}", url, Environment.NewLine);



                    File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + "ServerSampleRobots.txt", ms);
                }
            }
            

            string[] lines = System.IO.File.ReadAllLines(@"ServerSampleRobots.txt");

            string[] linesOfMyRobots = System.IO.File.ReadAllLines(@"Daily_Sheduled_Robots.txt");

            String timeStamp = GetTimestamp(DateTime.Now);
            String filename = "Result_On_" + timeStamp + ".txt";

            string[] lines2 = new String[lines.Length];

            for(int i = 0; i < lines.Length; i++)
            {
                lines2[i] = lines[i].Trim();
            }
           
            foreach (string line1 in linesOfMyRobots)
            {
                    int pos = Array.IndexOf(lines2, line1.Trim());
                    if (pos > -1)
                    {
                        String line = lines[pos];
                        var Today = DateTime.Now;
                        var Yesterday = DateTime.Now.AddDays(-1);
                        string x = Today.ToString("yyyy-MM-dd");
                        string y = Yesterday.ToString("yyyy-MM-dd");

                        string v = string.Format("http://checkmate.ukwest.cloudapp.azure.com:9100/documentServer/documentRepository/documents?query=SourceUrl:" + "\"" + "{0}" + "\"" + " AND PublishDate:" + "[" + y + " TO " + x + "]&sortByField=PublishDate&sortDescending=true", line);  //Adding Date

                        try
                        {

                            var response2 = new WebClient().DownloadString(v);
                            JObject jObj1 = JObject.Parse(response2);// C# object of JSONJObject jObj1 = JObject.Parse(response2);// C# object of JSON

                            try
                            {
                                if (jObj1["Documents"] != null && jObj1["Documents"].HasValues == true && response2 != null)
                                {
                                    string id = (string)jObj1["Documents"][1]["_id"];





                                    if (string.IsNullOrEmpty(id) == false)
                                    {
                                        //log.Info("ROBOID\tSUCCESS");
                                        strbuffer.Append(line + "====== Is Working\n");




                                    }
                                    else
                                    {
                                        strbuffer.Append(line + "======== Is Not Working\n");


                                    }
                                }
                                else
                                {
                                    strbuffer.Append(line + "======== Is Not Working\n");
                                }
                            }
                            catch (Exception e)
                            {
                                strbuffer.Append("Cant access to" + line + " due to " + e);
                            }

                        }

                        catch (Exception e)
                        {
                            strbuffer.Append("Cant access to" + line + " due to " + e);

                        }

                    }
                    
            }// onStart is finished


            File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + filename, strbuffer.ToString());

        }

        protected override void OnStop()
        {

            strbuffer.Append(" Service is stoped\n");
        }

        public String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmss");
        }

    }
}
